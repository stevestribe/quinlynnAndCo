# Inquire-section handoff — Quinlynn & Co.

**Target repo:** `stevestribe/quinlynnAndCo` (branch `main`)
**Files touched:** `site/index.html`, `site/css/styles.css`, `site/js/main.js`, `site/assets/quinlynn-q.png` (new)
**Owner:** Steve · prepared by design

## What this delivers

Merges the existing **`#custom`** (Custom Orders steps) and **`#contact`** (inquiry form) sections into a **single new Inquire section** built around a personal, handwritten-notecard pattern. The form reads like a short letter ("Dear Ashley, I'd love…") instead of a traditional labelled form. On submit, the whole card flips face-down with a 3D rotation to reveal a thank-you message — no full-page redirect, no scroll jump.

This is a markup + CSS + JS replacement only. Tokens, fonts, reveal animation, sticky CTA behaviour, and all other sections (Hero / About / Products / Footer) are unchanged.

## High-level diff

| File | Change |
|---|---|
| `site/index.html` | Delete the entire `<!-- ── Custom Orders ── -->` section. Replace the entire `<!-- ── Contact / Inquiry Form ── -->` section with the markup in `inquire-section.html`. Also: trim the `#custom` nav link and the drawer's `<em>03</em> Custom` link (notes below). |
| `site/css/styles.css` | Append the block in `inquire-section.css` to the end of the file. **Do not** remove the existing `.form-wrap` / `.field` / `.step-*` rules — they're harmless once the markup is gone and may be reused later. (If you want a tidy delete, see "Optional cleanup" below.) |
| `site/js/main.js` | Replace the entire **Contact form** IIFE (the last block, starting `// ── Contact form ──`) with the IIFE in `inquire-form.js`. |
| `site/assets/quinlynn-q.png` | Add this new asset. It's the standalone "Q" mark used in the notecard masthead. |

## Step-by-step

### 1. Add the new asset

Copy `claude_code_handoff/assets/quinlynn-q.png` into `site/assets/quinlynn-q.png`. (192×208 PNG, transparent, ~9KB.)

### 2. Update `site/index.html`

**a) Delete** the entire block between `<!-- ── Custom Orders ── -->` and the closing `</section>` that follows the `.cust-cta-row` div. That's the `#custom` section.

**b) Replace** the entire `<!-- ── Contact / Inquiry Form ── -->` block — from that comment through the closing `</section>` that follows the success-state `<div class="form-success">` — with the contents of `inquire-section.html`.

**c) Trim the nav** — open the `<nav class="nav-links">` block and delete this line:

```html
<a href="#custom">Custom</a>
```

**d) Trim the drawer** — in the `<div class="drawer-body">` block, delete this line:

```html
<a href="#custom" class="drawer-link"><em>03</em>&nbsp;&nbsp;Custom</a>
```

…and renumber the remaining drawer items so they read 01 / 02 / 03 instead of 01 / 02 / 04. (Inquire becomes `<em>03</em>`.)

**e) Update the footer** — in the `<div class="ft-col">` "Shop" list, change the `Custom orders` link from `href="#custom"` to `href="#contact"` (it now points to the merged Inquire section).

> The section's `id` stays as `#contact` so every existing internal hash (sticky CTA, nav, drawer, footer) keeps working untouched. If you'd rather rename it to `#inquire`, see "Optional cleanup" — it's a 5-place find/replace.

### 3. Update `site/css/styles.css`

Append the entire contents of `inquire-section.css` to the end of `site/css/styles.css`.

### 4. Update `site/js/main.js`

Find the last IIFE in the file — the one beginning `// ── Contact form ──`. Delete it entirely (from that comment through its closing `})();`). Append the contents of `inquire-form.js` in its place.

### 5. Smoke test

Open `site/index.html`, scroll to the Inquire section. Confirm:

1. The notecard renders with the "Q" tile + wordmark masthead at the top.
2. Typing in the inline fields underlines them on focus.
3. Clicking **Send the note** with empty fields shows the peach alert:
   `Be sure to add what you'd like made, a few details about it, your email, and your name before sending Ashley a note.`
4. Filling everything in and clicking Send: button reads "Sending…", then after ~0.9s the entire card flips 180° on the Y axis to reveal the thank-you message.
5. Clicking **Send another →** flips the card back and resets the form to blank.
6. Sticky-CTA pill hides whenever the submit button is on screen (same behaviour as before — driven by `body[data-contact-visible]`).

## Optional cleanup (do NOT do unless explicitly approved)

These are tidy-ups that aren't strictly required for the merge to ship. **Leave them for a follow-up unless Steve says otherwise.**

- **Remove stale CSS.** After confirming nothing else uses them, you can delete the orphaned `.form-wrap`, `.form-aside`, `.row`, `.field`, `.file-up`, `.file-choose-btn`, `.submit-row`, `.form-success`, `.cust-head`, `.cust-grid`, `.step*`, `.cust-cta-row`, `.etsy-card`, `.meta` blocks from `site/css/styles.css`. ~150 lines.
- **Rename section id.** Change the section's `id="contact"` → `id="inquire"` and find/replace `#contact` in: nav link, drawer link, footer "Custom orders" link, sticky CTA `href`, and the JS `body.dataset.contactVisible` → `body.dataset.inquireVisible` (plus the matching CSS selector `body[data-contact-visible="1"]`).
- **Drop the `home.md` `#custom` references** if any. (Steve to check `site/content/pages/home.md`.)

## Behaviour reference (so Code can sanity-check)

### Validation

Required fields, in document order:

| Field key | Form element | Friendly label (used in alert) |
|---|---|---|
| `interest` | the inline `<select>` ("I'd love …") | `what you'd like made` |
| `details`  | the `<textarea>` ("Here's what I have in mind") | `a few details about it` |
| `email`    | the inline email input | `your email` (or `a valid email` if filled but malformed) |
| `name`     | the signature `<input>` ("Yours, …") | `your name` |

The `details` field also fails if filled but under 12 characters.

The summary alert is **only shown after the first submit attempt** — not on field blur. After the first attempt it stays live and updates as the user fixes fields. Per-field underline tint (`.err`) still appears on blur so users get inline feedback while typing.

Sentence template + grammar:
- 1 field missing → `Be sure to add your email before sending Ashley a note.`
- 2 fields → `Be sure to add your email and your name …`
- 3+ fields → Oxford comma: `Be sure to add what you'd like made, your email, and your name …`

### Flip animation

- `<article class="card">` carries the `.reveal` class (handled by the existing scroll-reveal observer — do not touch).
- Inside it, a `<div class="flip-inner">` is the actual flipping element. **The `is-flipped` class toggles on `.flip-inner`, never on the `.card`** — otherwise the scroll-reveal observer's manually-added `.in` class collides with state-driven `className` rewrites in React, but the same lesson applies here: if you ever wire React/JSX into this, keep `.in` and `.is-flipped` on different elements.
- `.flip-front` (form) and `.flip-back` (thank-you message) share the card chrome (background, shadow, padding). The back is absolutely positioned and rotated 180° on Y; flipping the parent makes it face forward.
- `.flip-back` is `visibility: hidden` while face-down so it doesn't catch focus; the transition has a 1.05s delay on un-flip so it stays visible during the return animation.
- Honors `prefers-reduced-motion: reduce` (skips the rotate animation).

### Stub submit

`inquire-form.js` uses `setTimeout(..., 900)` as a placeholder. Replace this with a real endpoint (Resend / Formspree / a Netlify Function / etc.) when ready. The success path must:
1. Add `.is-flipped` to the `.flip-inner` element.
2. Toggle a `data-status="done"` attribute on the section (used to lock pointer events on the front face).

## Other deltas observed (for Steve to confirm or skip)

These are differences I noticed between the React prototype and the repo that **are not part of this merge**. Please confirm or deny each before I include any in a follow-up handoff.

1. **Submit button label.** Repo currently reads "Start a Custom Order". New section reads **"Send the note"**. *(Included in this handoff.)*
2. **Privacy microcopy** under the submit. Repo: `No newsletters · just a reply from Ashley`. New: `2–3 day reply · no newsletter`. *(Included.)*
3. **INTERESTS dropdown options** rewritten to match the conversational sentence ("I'd love **a tote or bag**.") — see `inquire-section.html`. Repo's options were more formal. *(Included.)*
4. **"Choose file" UI** changed from the underlined dashed row to an inline mono-cased "Attach a reference image" pill. *(Included.)*
5. **"Etsy aside" placement.** Repo puts the Etsy card *next to* the form, as a sidebar; new version puts it *below* the notecard as a single full-width hairline-separated row. *(Included — feels less crowded.)*
6. **`#custom` section deleted entirely.** The 3-step "Share / Discuss / Receive" cards are gone. The notecard implies the same flow without needing a separate marketing strip. *Confirm: are you happy losing those step cards? If you want them preserved, we can keep `#custom` and just merge the form-side rewrite.*
7. **Nav link "Custom" removed.** *(Follows from #6.)*
8. **Drawer renumbering.** With Custom gone, the drawer reads 01 / 02 / 03. *(Follows from #6.)*
9. **Success-state copy.** Repo's success screen says *"Your note is on its way to the studio."* with a longer paragraph. New flip-back says *"Thanks for dropping me a note."* + *"I'll be in touch soon — usually within two or three days."* + a `— Quinlynn` mono signature. *Confirm: prefer one over the other?*
10. **No more separate "Send another" + "Visit the Etsy shop" CTA pair.** The flip-back has just a single inline `Send another →` link in the mono style. *Confirm: want the Etsy CTA back on the success screen too?*

For each, reply **keep / drop / change to "…"** and I'll fold the answers into the final handoff or send a follow-up patch.
